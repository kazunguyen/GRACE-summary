import sys
from pathlib import Path
from types import SimpleNamespace

import math
import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from grace_diag import stats as S  # noqa: E402
from grace_diag import complementarity as C  # noqa: E402
from grace_diag.llm_backend import parse_top_logprobs, FirstTokenScorer  # noqa: E402


def synth(n=600, seed=0, signal=1.2, llm_signal=0.0):
    rng = np.random.default_rng(seed)
    y = (rng.random(n) < 0.4).astype(int)
    X = rng.normal(size=(n, 5)) + signal * y[:, None] * np.array([1, 0.5, 0, 0, 0])
    p_gate = 1 / (1 + np.exp(-(X[:, 0] + 0.5 * X[:, 1] - 0.6)))
    s_llm = 1 / (1 + np.exp(-(llm_signal * (2 * y - 1) + rng.normal(size=n))))
    valid = rng.random(n) > 0.01
    return y, X, p_gate, s_llm, valid


def test_mcc_none_for_constant():
    y = np.array([0, 1, 1, 0]); assert S.mcc(y, np.zeros(4, dtype=int)) is None
    assert S.mcc(y, y) == 1.0


def test_pick_threshold_deterministic():
    y, X, p, s, v = synth()
    t1, m1 = S.pick_threshold(y, p); t2, m2 = S.pick_threshold(y, p)
    assert t1 == t2 and 0.01 <= t1 <= 0.99 and m1 > 0.2


def test_paired_bootstrap_and_verdict():
    y, X, p, s, v = synth()
    strong = (p >= 0.5).astype(int); weak = (s >= 0.5).astype(int)
    ci = S.paired_bootstrap(y, weak, strong, S.mcc, n_boot=300, seed=1)
    assert ci.lo > 0 and S.verdict(ci, 0.03) == "benefit"
    ci2 = S.paired_bootstrap(y, strong, strong, S.mcc, n_boot=300, seed=1)
    assert ci2.lo == 0 == ci2.hi and S.verdict(ci2, 0.03) == "no_meaningful_benefit"
    groups = np.arange(len(y)) // 10
    ci3 = S.paired_bootstrap(y, weak, strong, S.mcc, n_boot=100, seed=1, groups=groups)
    assert ci3.unit == "cluster"


def test_mcnemar_and_holm():
    y = np.array([1] * 50 + [0] * 50); a = y.copy(); b = y.copy(); b[:10] = 0
    r = S.mcnemar_test(y, a, b); assert r["b"] == 10 and r["c"] == 0 and r["p_value"] < 0.01 and r["method"] == "exact"
    adj = S.holm({"x": 0.01, "y": 0.04, "z": 0.2}); assert adj["x"] == pytest.approx(0.03) and adj["z"] == pytest.approx(0.2)


def test_label_sensitivity():
    y = np.array([0, 1, 1, 0, 1]); b = np.array([0, 1, 0, 0, 1]); f = np.array([1, 0, 0, 0, 1]); r = b.copy()
    out = S.label_sensitivity(y, b, f, r)
    assert out["flip"] == pytest.approx(0.4) and out["natural"] == 0 and out["net"] == pytest.approx(0.4)


def test_repair_harm_reference_and_oracle():
    y, X, p, s, v = synth(llm_signal=0.0)
    h = (p >= 0.5).astype(int); g = (s >= 0.5).astype(int)
    rh = C.repair_harm(y, h, g, v); tot = rh["total"]
    assert tot["repair"] + tot["harm"] + tot["both_right"] + tot["both_wrong"] + tot["invalid_expert"] == len(y)
    ref = C.reference_experts(y, h, float(g.mean()), n_random=5)
    assert "ALL-0" in ref and ref["ALL-0"]["repair"] == int(((y == 0) & (h == 1)).sum())
    oc = C.oracle_ceiling(y, h, g, v); assert oc["oracle_accuracy"] >= oc["classifier_accuracy"]


def test_pre_post_no_signal_is_not_benefit():
    y, X, p, s, v = synth(llm_signal=0.0)
    res = C.fit_pre_post(X, s, v, p, y, n_boot=200, seed=3)
    assert res.verdict_mcc in ("inconclusive", "no_meaningful_benefit", "harm")
    y2, X2, p2, s2, v2 = synth(llm_signal=1.5, seed=5)
    res2 = C.fit_pre_post(X2, s2, v2, p2, y2, n_boot=200, seed=3)
    assert res2.delta_mcc.delta > 0.05


def test_routing_curves_shapes():
    y, X, p, s, v = synth()
    h = (p >= 0.5).astype(int); g = (s >= 0.5).astype(int)
    router = C.fit_benefit_router(X, y, h, g, v)
    rows = C.routing_curves(y, h, g, v, p, 0.5, ids=list(range(len(y))), benefit_scores=router.predict(X), n_random=3)
    pols = {r["policy"] for r in rows}
    assert {"gate_only", "full_expert_with_fallback", "random", "confidence", "benefit", "oracle"} <= pols
    q10 = [r for r in rows if r["policy"] == "oracle" and r["q"] == 0.10][0]
    assert q10["queries"] == int(np.ceil(0.10 * len(y)))


def test_parse_top_logprobs_and_response():
    out = parse_top_logprobs({"1": -0.2, " 0": -1.8, "The": -5.0})
    assert out["valid"] and out["pred_argmax"] == 1 and 0.8 < out["s"] < 0.9
    assert out["both_in_topk"] and not out["s_bounded"]
    none = parse_top_logprobs({"The": -0.1})
    assert none["valid"] is False and none["both_in_topk"] is False
    # chỉ "1" có mặt: "0" nhận cận trên = p(token thấp nhất trong top-k), KHÔNG phải 0
    one = parse_top_logprobs({"1": -0.05, "The": -4.0, "Yes": -6.0})
    assert one["valid"] and one["s_bounded"] and not one["both_in_topk"]
    assert one["p0"] == pytest.approx(math.exp(-6.0)) and one["s"] < 1.0 and one["pred_argmax"] == 1
    top = [SimpleNamespace(token="0", logprob=-0.1), SimpleNamespace(token="1", logprob=-2.4)]
    resp = SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content="0"),
                                                    logprobs=SimpleNamespace(content=[SimpleNamespace(token="0", logprob=-0.1, top_logprobs=top)]))],
                           usage=SimpleNamespace(prompt_tokens=1500, completion_tokens=1))
    r = FirstTokenScorer.parse_response(resp, 0.1)
    assert r.valid and r.pred_argmax == 0 and r.s < 0.2 and r.usage["prompt_tokens"] == 1500


def test_request_key_and_repeat_tag():
    from grace_diag.llm_backend import BackendConfig, request_key
    cfg = BackendConfig(base_url="http://x", model="m")
    k0 = request_key("prompt", cfg)
    assert k0 == request_key("prompt", cfg) and k0 != request_key("prompt", cfg, tag="repeat")


def test_locked_thresholds_roundtrip(tmp_path):
    from grace_diag import thresholds as T
    val = {("devign", "B2", 42): {"y": [0, 1, 0, 1, 1, 0, 1, 0], "s": [0.1, 0.9, 0.3, 0.8, 0.55, 0.45, 0.7, 0.2]},
           ("devign", "B2-rep", 42): {"y": [0, 1], "s": [0.2, 0.8]}}
    arms = {"B2": {"name": "B2"}, "B2-rep": {"name": "B2-rep", "threshold_from": "B2"}, "B2-flip": {"name": "B2-flip", "threshold_from": "B2"}}
    th = T.compute_thresholds(val, arms)
    assert th["devign|B2|42"]["policy"] == "argmax_mcc_validation"
    assert th["devign|B2-rep|42"]["tau"] == th["devign|B2|42"]["tau"] == th["devign|B2-flip|42"]["tau"]
    assert th["devign|B2-flip|42"]["policy"] == "inherit_from:B2"
    out = tmp_path / "thresholds.json"
    digest = T.write_locked(out, th, {"f": "abc"}, "0.01..0.99")
    loaded = T.load_locked(out)
    assert loaded["devign|B2|42"]["tau"] == th["devign|B2|42"]["tau"] and len(digest) == 64
    # sửa tay file đã khóa -> phát hiện
    assert th["devign|B2|42"]["tau"] == 0.5          # tách hoàn hảo, hòa -> gần 0,5
    txt = out.read_text(encoding="utf-8").replace('"tau": 0.5', '"tau": 0.37', 1)
    assert '"tau": 0.37' in txt
    out.write_text(txt, encoding="utf-8")
    with pytest.raises(SystemExit):
        T.load_locked(out)


def test_import_and_compare_scripts(tmp_path):
    import json, subprocess, sys
    root = Path(__file__).resolve().parents[1]
    src = tmp_path / "repo" / "06_Arm_X" / "seed_42" / "devign" / "test"
    src.mkdir(parents=True)
    rows = [{"id": f"devign:test:{i}", "dataset": "Devign", "split": "test", "arm": "B2", "label": i % 2, "s": 0.1 + 0.8 * (i % 2),
             "valid": True, "runtime_contract_sha256": "r1", "timestamp": f"2026-11-07T00:00:{i:02d}+00:00"} for i in range(20)]
    (src / "records.jsonl").write_text("\n".join(json.dumps(r) for r in rows), encoding="utf-8")
    dst = tmp_path / "runs"
    out = subprocess.run([sys.executable, str(root / "scripts" / "import_records.py"), "--src", str(tmp_path / "repo"), "--dst", str(dst)],
                         capture_output=True, text=True)
    assert out.returncode == 0, out.stdout + out.stderr
    rec = dst / "devign" / "test" / "B2" / "42" / "records.jsonl"
    assert rec.exists() and len(rec.read_text().strip().splitlines()) == 20
    man = json.loads((dst / "devign" / "test" / "B2" / "42" / "import_manifest.json").read_text())
    assert man["mixed_runtime"] is False and man["n_valid"] == 20
    # xung đột: cùng id, s khác -> abort
    dup = tmp_path / "repo" / "other" / "records.jsonl"
    dup.parent.mkdir(parents=True)
    bad = dict(rows[0]); bad["s"] = 0.5; bad["runtime_contract_sha256"] = "r2"
    dup.write_text(json.dumps(bad), encoding="utf-8")
    out = subprocess.run([sys.executable, str(root / "scripts" / "import_records.py"), "--src", str(tmp_path / "repo"), "--dst", str(tmp_path / "runs2")],
                         capture_output=True, text=True)
    assert out.returncode != 0 and "XUNG ĐỘT" in out.stdout
    # compare: bản sao bit-identical -> ghi chú tất định/cache
    rep_dir = dst / "devign" / "test" / "B2-rep" / "42"; rep_dir.mkdir(parents=True)
    (rep_dir / "records.jsonl").write_text(rec.read_text(), encoding="utf-8")
    out = subprocess.run([sys.executable, str(root / "scripts" / "compare_records.py"), "--a", str(rec), "--b", str(rep_dir / "records.jsonl"), "--tau", "0.7"],
                         capture_output=True, text=True)
    assert out.returncode == 0
    j = json.loads(out.stdout)
    assert j["share_bitwise_identical_s"] == 1.0 and j["flip_rate_at_tau"] == 0.0 and any("tất định" in n for n in j["notes"])
