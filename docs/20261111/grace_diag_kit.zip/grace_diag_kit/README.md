# grace_diag_kit — bộ công cụ cho lượt chạy xác nhận "tái lập có chẩn đoán" GRACE

Gói này bổ sung cho hai bản mã hiện có của nhóm (repo tái triển khai với `prompt_contract.py`,
`run_verified_experiment.py`; và gói H3-B `grace_h3v2`) đúng những phần còn thiếu của đề cương:

| Phần | File | Trả lời cho |
| --- | --- | --- |
| Bộ dựng prompt theo Hình 6 + 15 arm/probe thay-một-thành-phần | `src/grace_diag/probes.py`, `configs/arms.yaml` | RQ1–RQ3 |
| Ngân sách context bằng token của tokenizer model | `src/grace_diag/token_budget.py` | Mục 6.4 |
| Gọi LLM tự host (vLLM / llama.cpp) và lấy điểm số s từ logprob token đầu | `src/grace_diag/llm_backend.py`, `configs/backend_*.yaml` | RQ4 |
| Kiểm tra toàn vẹn prompt trước khi gọi LLM | `src/grace_diag/prompt_audit.py` | Bước 3 |
| Mốc có giám sát SUP-LR / SUP-MLP / SUP-METRIC | `src/grace_diag/supervised_anchor.py` | RQ5 |
| Giá trị bổ sung: P_pre/P_post, sửa–hỏng theo lớp với đối chứng expert hằng/ngẫu nhiên, trần oracle, routing theo ngân sách | `src/grace_diag/complementarity.py` | RQ5b |
| Bootstrap ghép cặp (từng mẫu hoặc theo cụm), McNemar, Holm, biên δ và quy tắc kết luận 4 ô, độ nhạy nhãn | `src/grace_diag/stats.py` | Mục 6.6 |
| Sinh bảng A/B/C + hình từ `runs/final` | `src/grace_diag/evaluate_final.py` | Bước 7 |
| Chạy ma trận có journal/resume/cache; smoke test; manifest; gói ca chấm mù | `scripts/*.py` | Bước 1, 2, 5, 8 |
| Giao thức đăng ký trước dạng máy đọc được | `configs/protocol.yaml` | Bước 4 |

## Cài đặt

```bash
pip install -e grace_diag_kit            # numpy, scipy, scikit-learn, pyyaml, openai
pip install transformers                 # tokenizer của model (bắt buộc cho lượt chạy thật)
pip install matplotlib pytest            # hình và kiểm thử
python -m pytest grace_diag_kit/tests    # 29 test phải xanh trước khi dùng
```

## Thứ tự chạy (tóm tắt; chi tiết ở Mục 7–8 của đề cương)

```bash
# 0. (3 ngày đầu) phân tích offline từ dự đoán đã có — không cần GPU
python -m grace_diag.complementarity --val val.csv --test test.csv --tau 0.53 --out runs/complementarity_devign.json

# 1. server LLM + smoke test
vllm serve Qwen/Qwen3-Coder-30B-A3B-Instruct --max-model-len 8192 --seed 42 --enable-prefix-caching --port 8000
python scripts/run_matrix.py --dataset devign --split validation --specs data/specs/devign_validation.jsonl \
    --donors data/manifests/devign_donors.jsonl --arms B2 --dry-run --out runs/dryrun
python scripts/smoke_test_backend.py --backend configs/backend_vllm.yaml --prompts runs/dryrun/prompts_devign_validation.jsonl

# 2. đóng băng dữ liệu
python scripts/build_manifests.py --train raw/devign_train.jsonl --validation raw/devign_validation.jsonl \
    --test raw/devign_test.jsonl --dataset devign --out data/manifests
python scripts/convert_verified_plan.py --plan <plan schema v2 của repo> --out data/specs/devign_validation.jsonl

# 3. audit prompt (mọi arm, split validation) rồi mới đăng ký trước
python scripts/run_matrix.py ... --arms $(python -c "import yaml;print(' '.join(a['name'] for a in yaml.safe_load(open('configs/arms.yaml'))['arms']))") --dry-run --out runs/dryrun
python -m grace_diag.prompt_audit --prompts runs/dryrun/prompts_devign_validation.jsonl --out-dir runs/dryrun/audit

# 5. ma trận: validation trước -> KHÓA τ* -> test một lần (thứ tự bắt buộc)
python scripts/run_matrix.py --dataset devign --split validation --specs ... --donors ... --arms B0 B1 B2 B2-flip B2-rep --seeds 42 --backend configs/backend_vllm.yaml --out runs/final

# 6. mốc có giám sát (validation + test; τ* của SUP-* cũng khóa ở bước 6b)
python -m grace_diag.supervised_anchor --dataset devign --emb-train ... --emb-val ... --emb-test ... --code-train ... --code-val ... --code-test ... --out-dir runs/anchor

# 6b. khóa ngưỡng CHỈ từ validation (ghi sha256; B2-rep/B2-flip thừa kế τ* của B2, B3-flip/B3-swap của B3)
python -m grace_diag.thresholds --runs runs/final --arms configs/arms.yaml --anchor-csv runs/anchor/anchor_scores.csv --out runs/thresholds.json

# 6c. test — chỉ sau khi runs/thresholds.json đã được commit
python scripts/run_matrix.py --dataset devign --split test       --specs ... --donors ... --arms B0 B1 B2 B2-flip B2-rep --seeds 42 --backend configs/backend_vllm.yaml --out runs/final

# 7. bảng và hình (đọc ngưỡng đã khóa; thiếu ngưỡng cho arm có test = lỗi, không mặc định 0,5)
python -m grace_diag.evaluate_final --runs runs/final --protocol configs/protocol.yaml --anchor-csv runs/anchor/anchor_scores.csv --thresholds runs/thresholds.json --out runs/tables

# 7b. nếu ngưỡng đăng ký đã bị thay sau khi có test: chạy hai lần, báo cả hai bộ
python -m grace_diag.thresholds --runs runs/final --arms configs/arms.yaml --out runs/thresholds_corrected.json --compare configs/thresholds.prereg.json
python -m grace_diag.evaluate_final ... --thresholds configs/thresholds.prereg.json  --out runs/tables_prereg
python -m grace_diag.evaluate_final ... --thresholds runs/thresholds_corrected.json --out runs/tables_corrected
```

## Dùng với records đã có sẵn trong repo thực nghiệm (bố cục thư mục khác)

```bash
# gom mọi records*.jsonl về bố cục của bộ công cụ; dataset/split/arm/seed đọc từ chính record;
# trùng id với s khác nhau giữa hai file = xung đột (trộn runtime) -> dừng và liệt kê
python scripts/import_records.py --src /path/to/GRACE-summary --dst runs/final --dry-run
python scripts/import_records.py --src /path/to/GRACE-summary --dst runs/final [--groups-csv groups.csv]

# so hai file trên cùng ID: B2 với B2-rep (kiểm chứng lặp), cùng arm ở hai môi trường, B2 với B2-flip
python scripts/compare_records.py --a runs/final/devign/test/B2/42/records.jsonl --b runs/final/devign/test/B2-rep/42/records.jsonl --tau 0.70

# metric phân tầng theo tập con ID hoặc theo một trường của record (vd. B1-H2 có/không evidence)
python scripts/subset_metrics.py --records runs/final/reveal/test/B1-H2/42/records.jsonl --field evidence_missing --value false --tau 0.21
```

Quy tắc đọc Bảng B: cột `exposure_status` đánh dấu arm đã xem test trước đăng ký; cột `ppr@0.5_a/b` là tỷ lệ
đoán 1 ở **cùng** ngưỡng 0,5 — chỉ so điểm hoạt động giữa các arm ở cột này, không so `ppr@tau` của Bảng A
giữa hai arm có τ* khác nhau (đó là so ngưỡng, không phải so model).

```bash
# 8. gói ca chấm mù phân tầng
python scripts/make_case_packets.py --records runs/final/devign/test/B2/42/records.jsonl --anchor runs/anchor/anchor_scores.csv --tau 0.53 --code raw/devign_test.jsonl --out packets/devign_B2
```

Định dạng dữ liệu vào/ra, cách nối với mã hiện có và các chỗ cần sửa trong repo được mô tả
trong `integration/INTEGRATION.md`.

## Nguyên tắc mã

- Nhãn của target không bao giờ đi vào `render_arm` (hàm từ chối khi thấy trường `target`/`label`).
- Mỗi arm khác arm gốc đúng một khối; `tests/test_probes.py` kiểm tra điều này bằng `diff_blocks`.
- Mọi lượt gọi LLM được cache theo `sha256(prompt | model | tham số | parser_version | tag)`; đổi model
  hay tham số là một cache khác. Arm `repeat: true` (B2-rep) luôn gọi model mới với `tag="repeat"` và
  không ghi/đọc cache của arm gốc — một lượt "lặp" lấy lại câu trả lời cũ không đo được gì.
- Điểm s tính từ top-k logprob (k = 20). Token 0/1 vắng trong top-k nhận cận trên
  p ≤ p(token thấp nhất trong top-k) và được gắn cờ `s_bounded`; smoke test yêu cầu ≥ 99% prompt có cả hai token.
- Ngưỡng τ* chỉ được chọn trên validation bằng `grace_diag.thresholds`, khóa bằng sha256 và chỉ được ĐỌC
  khi đánh giá test; probe lặp/đảo nhãn/đảo thứ tự thừa kế τ* của arm gốc (`threshold_from` trong arms.yaml).
- Metric không xác định (MCC của predictor hằng, AUROC khi thiếu một lớp) trả `None`/`N/A`, không ép 0;
  số lượt bootstrap suy biến được báo cáo cùng CI.
- Kết luận đọc từ CI và biên δ đã khai báo: `benefit`, `no_meaningful_benefit`, `harm`, `inconclusive`.
